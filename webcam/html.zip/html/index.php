<?php 
	include("header.php");
	include('dbconnection.php');
?>
<!DOCTYPE html>
<html>
	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style>
		body {
			background: #555;
		}
		.content {
			max-width: 500px;
			margin: auto;
			background: white;
			padding: 10px;
		}	
	</style>
	</head>
	<body>
	<div class="content">
	<h1>Welcom to Athom </h1>  
	</div>
	</body>
</html>
<script>
	setTimeout(function(){ 
		var request = $.ajax({
			url: 'checkdetails.php',
			type: "POST",
			dataType:'json',
			data:{looser_form: 'looser_form'}               
		});
		request.done(function(msg) {
			window.location = "results.php";
		});
		request.fail(function(jqXHR, textStatus) {
			window.location = "index.php";
		});
	},3000);	
</script>
